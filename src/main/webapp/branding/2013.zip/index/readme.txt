Query for unassigned cards:
SELECT * FROM RfidCard WHERE human=NULL

SELECT * FROM RfidCard where serialNumber='81315AA4'

Query for Human by Name
SELECT * FROM Human WHERE name='Jachna-Szmigielska Klara'